import React from 'react';

const GlobalContext = React.createContext({categories: []});

export default GlobalContext;