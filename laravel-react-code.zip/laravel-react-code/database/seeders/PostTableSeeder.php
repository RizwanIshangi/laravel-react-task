<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Post;
use Illuminate\Support\Facades\Hash;


class PostTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Post::create([
            'title' => 'Sample Product',
            'slug' => 'Sample-Product',
            'content' => '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>',
            'image' => '1698557797-653def650b801.jpeg',
            'category_id' => 1,
            'user_id' => 1,
        ]);
       Post::create([
            'title' => 'Rangefinder camera',
            'slug' => 'Rangefinder-camera',
            'content' => '<h2>What is Lorem Ipsum?</h2><p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><p><br>&nbsp;</p>',
            'image' => '1698557739-653def2bde060.jpeg',
            'category_id' => 1,
            'user_id' => 1,
        ]);
       Post::create([
            'title' => 'Camera | instax | FUJIFILM',
            'slug' => 'Camera-|-instax-|-FUJIFILM',
            'content' => '<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text</p>',
            'image' => '1698575647-653e351f6c814.png',
            'category_id' => 1,
            'user_id' => 1,
        ]);
       Post::create([
            'title' => 'Dell Laptop PC — Dell Laptops',
            'slug' => 'Dell-Laptop-PC-—-Dell-Laptops',
            'content' => '<p>There are many variations of laptop 👨‍💻👩‍💻💻of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text.</p><p><br>&nbsp;</p>',
            'image' => '1698557739-653def2bde060.jpeg',
            'category_id' => 2,
            'user_id' => 1,
        ]);
       Post::create([
            'title' => 'HP Pavilion Laptop',
            'slug' => 'HP-Pavilion-Laptop-1',
            'content' => '<p>👨‍💻👩‍💻💻Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage,</p>',
            'image' => '1698559668-653df6b4acd8f.jpeg',
            'category_id' => 2,
            'user_id' => 1,
        ]);
       Post::create([
            'title' => 'HP Laptop',
            'slug' => 'HP-Laptop',
            'content' => '<p><strong>Lorem Ipsum</strong> &nbsp;👨‍💻👩‍💻💻🥞 is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries</p>',
            'image' => '1698575365-653e340574895.png',
            'category_id' => 2,
            'user_id' => 1,
        ]);
    }
}
