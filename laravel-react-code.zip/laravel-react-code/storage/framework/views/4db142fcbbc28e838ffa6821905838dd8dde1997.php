<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>IKONIC Task | Admin</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin')); ?>/bower_components/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin')); ?>/bower_components/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin')); ?>/dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin')); ?>/dist/css/skins/skin-green.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin')); ?>/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-green sidebar-mini">

    <div id="app"></div>
    <script src="<?php echo e(asset('js/admin.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('assets/admin')); ?>/bower_components/jquery/dist/jquery.min.js"></script>
    <script src="<?php echo e(asset('assets/admin')); ?>/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('assets/admin')); ?>/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <script src="<?php echo e(asset('assets/admin')); ?>/dist/js/adminlte.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel-react-blog\resources\views/admin.blade.php ENDPATH**/ ?>